This file contains the latest binary for the NodeMCU 32S hardware. It will work with most other ESP32 development boards as well.

To install, unzip this file into a directory, connect the ESP32 to the USB port and run the batch file. It should then automatically find the ESP32 and install both, the SPIFFS disk and the executable.